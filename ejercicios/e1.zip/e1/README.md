### Archivo descriptivo
En este caso, se hallan los scrips para cifrados. Son solamente "librerias" propias
para poder desarrollar o implementar cifrados para el laboratorio 1.

Tomar en cuenta que se utilizo un entorno virutal de python

python -m venv <nombre_del_entorno>

### Ejecutar entorno en windos
```
<nombre_del_entorno>\Scripts\activate
```
## Ejecutar el entorno en Linux
```
source <nombre_del_entorno>/bin/activate
```

Tomar en cuenta que los elementos necesarios para su compilacion, estan en requirements.txt.
